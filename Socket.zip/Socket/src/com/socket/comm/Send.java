package com.socket.comm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import com.socket.comm.utils.AcountUtil;
import com.socket.comm.utils.CloseUtil;

/**
 * ���������߳�
 */
public class Send implements Runnable {
	
	private BufferedReader console; //����̨����������
	private BufferedWriter bw;		//�ܵ����������
	private boolean isRunning = true;
	private String userId;
	
	public Send() {
		console = new BufferedReader(new InputStreamReader(System.in));
	}
	
	public Send(Socket client,String userId) {
		this();
		try {
			bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			this.userId = userId;
			send(this.userId);
		} catch (IOException e) {
			//e.printStackTrace();
			isRunning = false;
			CloseUtil.closeAll(bw,console);
		}
	}
	
	/**
	 * ��ȡ����̨��Ϣ
	 */
	private String getMsgFromConsole() {
		try {
			return console.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * ���Ϳ���̨�������Ϣ
	 */
	public void send(String msg) {
		try {
			if(msg != null && !msg.trim().equals("")) {
				bw.write(msg);
				bw.newLine();
				bw.flush(); //ǿ��ˢ��
			}
		} catch (IOException e) {
			//e.printStackTrace();
			isRunning = false;
			CloseUtil.closeAll(bw,console);
		}
	}
	
	@Override
	public void run() {
		while(isRunning) {
			send(getMsgFromConsole());
		}
	}
}
