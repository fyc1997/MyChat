package com.socket.comm.entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.socket.comm.utils.AcountUtil;

public class User {
    private String userId = null;     //���ݵ�Ψһ��ʶ���Զ�����
    private String userName = null;   //�û���
    private String password = null;   //����
    private String phone = null;      //�ֻ���
    private String motto = null;      //����ǩ��
    private String sex = null;        //�Ա�
    private String birthday = null;   //����
    private String address = null;    //��ַ
    private String photo = null;      //ͷ��
    private String background = null; //����

    public User() {
        this.userName = "�������ο�";
    }

    public User(String userId) {
        this.userId= userId;//�Զ�����
        this.userName = "�������ο�";
    }

    public User(String phone,String password) {
        this.phone = phone;
        this.password = password;
    }

    public User(String userName, String password, String phone, String motto,
                 String birthday, String address,String photo,String background) {
        this.userId= AcountUtil.createToken();//�Զ�����
        this.userName = userName;
        this.password = password;
        this.phone = phone;
        this.motto = motto;
        this.birthday = birthday;
        this.address = address;
        this.photo = photo;
        this.background = background;
    }

    public String getUserId() {return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() { return password; }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthday() { return birthday; }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(int sex) {
        if(sex == 0){
            this.sex = "Ů";
        }else {
            this.sex = "��";
        }
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMotto(){ return motto; }

    public void setMotto(String motto){ this.motto = motto; }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    @Override
    public String toString() {
        return "User [userName=" + userName + ", userId=" + userId + ", phone=" + phone + ", motto=" + motto
                + ", sex=" + sex + ", birthday=" + birthday + ", address=" + address + ", photo="
                + photo + ", background=" + background + "]";
    }
}
