package com.socket.comm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.socket.comm.entity.User;
import com.socket.comm.utils.CloseUtil;
import com.socket.comm.utils.DBUtil;

//ʵ����Ⱥ��
public class Server {
	public static final String bm="GBK";
	private List<MyChannel> all = new ArrayList<MyChannel>();
	public static void main(String[] args) throws IOException {
		new Server().start();
	}
	
	public void start() throws IOException {
		ServerSocket server = new ServerSocket(9999);
		while(true) {
			Socket client = server.accept();
			MyChannel channel = new MyChannel(client);
			all.add(channel); //ͳһ����
			new Thread(channel).start();
		}	
	}
	
	/**
	 * һ���ͻ��˽���һ����·
	 * ������    �����    ��������    ��������
	 */
	private class MyChannel implements Runnable{
		
		private BufferedReader br;
		private BufferedWriter bw;
		private boolean isRunning = true;
		private boolean closable = false;
		private String userId;
		public MyChannel(Socket client) {
			try {
				br = new BufferedReader(new InputStreamReader(client.getInputStream(),bm));
				bw = new BufferedWriter(new OutputStreamWriter(client.getOutputStream(),bm));
				this.userId = br.readLine();
				//System.out.println(this.userId);
				//String userName = DBUtil.select("select * from user where userId='"+userId+"';").getUserName();
			} catch (IOException e) {
				isRunning = false;
				CloseUtil.closeAll(bw,br);
			}
		}
		
		/**
		 * ��������
		 */
		private String receive() {
			String msg = "";
			try {
				while((msg = br.readLine())==null);
				System.out.println(msg);
			} catch (IOException e) {
				isRunning = false;
				CloseUtil.closeAll(br);
				all.remove(this);//�Ƴ�����
			}
			return msg;
		}
		
		/**
		 * ��������
		 */
		public void send(String msg) {
			if(msg == null || msg.trim().equals("")) {
				return ;
			}
			try {
				bw.write(msg);
				bw.newLine();
				bw.flush();
			} catch (IOException e) {
				isRunning = false;
				CloseUtil.closeAll(bw);
				all.remove(this);//�Ƴ�����
			}
		}

		/**
		 * ���͸������û�
		 */
		private void sendOthers(String msg,boolean sys) {
			String context = msg.substring(msg.indexOf(":")+1);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			if(msg == null || msg.trim().equals("")) {
				return;
			}
			//�Ƿ�Ϊ˽��
			if(msg.toUpperCase().startsWith("@-") && msg.contains(":")) {
				String userIdTo = msg.substring(2,msg.indexOf(":"));
				if(!context.trim().equals("")) {
					User user = DBUtil.select("select * from user where userId='"+userIdTo+"';");
					String phone = user.getPhone();
					if(!phone.equals("")) {
						DBUtil.executeSql("insert into send(userIdFrom,userIdTo,content,time) values('"
								+userId+"','"+userIdTo+"','"+context+"','"+sdf.format(new Date())+"');");
						DBUtil.executeSql("insert into chatLog(userIdFrom,userIdTo,content,time) values('"
								+userId+"','"+userIdTo+"','"+context+"','"+sdf.format(new Date())+"');");
						return;
					}
				}
				send("failure");
			}else if(msg.toUpperCase().startsWith("@ALL") && msg.contains(":")){ //Ⱥ��	
				if(sys == true) {
					DBUtil.executeSql("insert into send(userIdFrom,userIdTo,content,time) values('"
							+"sys"+"','"+"all"+"','"+context+"','"+sdf.format(new Date())+"');");
				}else {
					DBUtil.executeSql("insert into send(userIdFrom,userIdTo,content,time) values('"
							+userId+"','"+"all"+"','"+context+"','"+sdf.format(new Date())+"');");
				}
			}else if(msg.toUpperCase().startsWith("@SQL:") && (msg.toUpperCase().contains("INSERT")||msg.toUpperCase().contains("UPDATE")||msg.toUpperCase().contains("DELETE")) ) {
				//Insert into XX(..) values(...) 
				//Update XX set ..=.. where ..=..
				//Delete from XX where ..=..
				DBUtil.executeSql(context);
			}else if(msg.toUpperCase().startsWith("@SQL:") && msg.toUpperCase().contains("SELECT")) {
				//select .. from XX
				User user = DBUtil.select(context);
				send(user.toString());
			}else if(msg.toUpperCase().startsWith("@SQL-SEND:") && msg.toUpperCase().contains("SELECT")) {
				String str = DBUtil.getChatLog(context);
				if(str.equals("")) {
					send("nothing");
				}else {
					send(str);
					System.out.println(str);
					String[] chatLog = str.split(";");
					for(int i=0;i<chatLog.length;i++) {
						String userIdFrom = chatLog[i].substring(chatLog[i].indexOf("From:")+5, chatLog[i].indexOf(",To"));
						String userIdTo = chatLog[i].substring(chatLog[i].indexOf("To:")+3, chatLog[i].indexOf(",Time"));
						DBUtil.executeSql("delete from send where userIdFrom='"+userIdFrom+"' and userIdTo='"+userIdTo+"';");
					}
				}
			}else if(msg.toUpperCase().startsWith("@SQL-FRIEND:") && msg.toUpperCase().contains("INSERT")) {
				String str = DBUtil.executeAddSql(context);
				if(str.equals("failure")) {
					send("failure");
				}else {
					send("success");
				}
			}else if(msg.toUpperCase().startsWith("@SQL-FRIEND:") && msg.toUpperCase().contains("SELECT")) {
				String str = DBUtil.addFriend(context);
				if(str.equals("")) {
					send("nothing");
				}else {
					send(str);
					System.out.println(str);
				}
			}
			closable = true;
		}
		
		@Override
		public void run() {
			while(isRunning) {
				sendOthers(receive(),false); //���͸������û�
				if(closable==true) {
					all.remove(this);
				}
			}
		}
	}
}
