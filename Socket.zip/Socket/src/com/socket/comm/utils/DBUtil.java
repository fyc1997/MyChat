package com.socket.comm.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.socket.comm.entity.User;

public class DBUtil {
	//����Mysql�����ݿ���������
	public static final String DBDRIVER = "com.mysql.jdbc.Driver";
	//����Mysql�����ݿ�����ӵ�ַ
	public static final String DBURL = "jdbc:mysql://localhost:3306/chat";
	//����Mysql�����ݿ�������û���
	public static final String DBUSER = "root";
	//����Mysql�����ݿ����������
	public static final String DBPASS = "mysqladmin";
	//�������ݿ�����
	private static Connection conn=null;
	//���ݿ����
	private static Statement stmt=null;    
	
	public static void connect() {
		try{
			Class.forName(DBDRIVER);//������������
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			conn = DriverManager.getConnection(DBURL,DBUSER,DBPASS);
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static void close() {
		try{
			stmt.close();		//�رղ���
			conn.close();		//�ر����ݿ�
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
	public static void executeSql(String sql) {
		connect();	
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			stmt.executeUpdate(sql);    //ִ�����ݿ���²���
		} catch (SQLException e) {
			//e.printStackTrace();
			rollback(conn);
		}
		close();
	}
	
	public static void rollback(Connection conn) {
		if(conn != null) {
			try {
				conn.rollback();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@SuppressWarnings("finally")
	public static String selectAll(String sql) {
		String str ="";
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				str+="User:"+rs.getString("userId")+"|;";
			}
			rs.close();
			close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				return str;
			}
	}

	@SuppressWarnings("finally")
	public static User select(String sql) {
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		User user = null;
		if(sql.toLowerCase().contains("userid")) {
			//@sql:select * from user where userId='b138b92259734df080425358a1330669';
			String userId = sql.substring(sql.indexOf("userId='")+8,sql.length()-2);
			user = new User(userId);
		}else if(sql.toLowerCase().contains("phone") && sql.toLowerCase().contains("password")){
			//@sql:select * from user where phone='15158656338' and password='fyc19970120';
			String phone = sql.substring(sql.toLowerCase().indexOf("phone='")+7,sql.toLowerCase().indexOf("' and"));
			String password = sql.substring(sql.toLowerCase().indexOf("password='")+10,sql.indexOf("';"));
			user = new User(phone,password);
		}else if(sql.toLowerCase().contains("phone")) {
			//@sql:select * from user where phone='"+phone+"';"
			String phone = sql.substring(sql.toLowerCase().indexOf("phone='")+7,sql.toLowerCase().indexOf("';"));
			user = new User(phone,"");
		}else { //select * from user
			user = new User();
		}
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql);    
			while(rs.next()) {
				user.setUserName(rs.getString("userName"));
				user.setUserId(rs.getString("userId"));
				//user.setPassword(rs.getString("password"));
				user.setMotto(rs.getString("motto"));
				user.setSex(rs.getInt("sex"));
				user.setPhone(rs.getString("phone"));
				String birth = new SimpleDateFormat("yyyy-MM-dd").format(rs.getDate("birthday"));
				user.setBirthday(birth);
				user.setAddress(rs.getString("address"));
				user.setPhoto(rs.getString("photo"));
				user.setBackground(rs.getString("background"));
			}
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return user;
		}
	}
	
	@SuppressWarnings("finally")
	public static String getChatLog(String sql) {
		//@sql-send:select * from send where userIdTo='b138b92259734df080425358a1330669';
		String str="";
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql); 
			while(rs.next()) {
				//From:userId,To:userId,Time:time,Content:content;
				str+="From:"+rs.getString("userIdFrom")+",";
				str+="To:"+rs.getString("userIdTo")+",";
				str+="Time:"+rs.getTimestamp("time")+",";
				str+="Content:"+rs.getString("content")+"|;";
			}
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return str;
		}
	}
	
	public static String executeAddSql(String sql) {
		//insert into friend(userId,myUserId,flag,rename,group) values('','',0,'zhangsan','����');
		//@SQL-FRIEND:insert into friend(userId,myUserId,flag,remark,myGroup,description) values('b138b92259734df080425358a1330669','fc454c4ba4274e819783d4298fb64df8',0,'���','����','���Ƿ��');
		//flag=0��ʾ��������δͬ��
		String userId = sql.substring(sql.indexOf("values('")+8,sql.indexOf("',"));
		String myUserId = sql.substring(sql.indexOf("','")+3,sql.indexOf("',0"));
		String exe = "select * from friend where myUserId='"+myUserId+"' and userId='"+userId+"';";
		String str = addFriend(exe);
		if(str.equals("")) {
			connect();
			try {
				stmt= conn.createStatement();  //ʵ����Statement����
				stmt.executeUpdate(sql);    //ִ�����ݿ���²���
			} catch (SQLException e) {
				e.printStackTrace();
			}
			close();
			return "success";
		}else {
			return "failure";
		}
	}
	
	@SuppressWarnings("finally")
	public static String addFriend(String sql) {
		//select * from friend where userId='' and flag=0;
		//select * from friend where myUserId='' and flag=1 or 2;
		String str="";
		connect();	
		ResultSet rs = null; //���ݿ�Ĳ�������
		try {
			stmt= conn.createStatement();  //ʵ����Statement����
			rs = stmt.executeQuery(sql); 
			while(rs.next()) {
				//To:myUserId,From:userId,Content:description,Remark:remark,MyGroup:myGroup|;
				str+="To:"+rs.getString("myUserId")+",";
				str+="From:"+rs.getString("userId")+",";
				str+="Content:"+rs.getString("description")+",";
				str+="Remark:"+rs.getString("remark")+",";
				str+="MyGroup:"+rs.getString("myGroup")+"|;";
			}
			rs.close();
			close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return str;
		}
	}
	
	public static void main(String args[]) {
		connect();
		System.out.println(conn); //�����ʱ���Դ�ӡ��ʾ��������
		//System.out.println(select("select * from user;"));
	}
}
